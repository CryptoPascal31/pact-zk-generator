Private keys are stored here:
   - testnet-gas.key.yaml
   - mainnet-gas.key.yaml
   - testnet-gov.key.yaml
   - mainnet-gov.key.yaml
